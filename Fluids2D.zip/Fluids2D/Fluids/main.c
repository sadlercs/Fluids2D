

/*
2D simple solver based off of GDC2003 paper - " Real Time Fluid Dynamics
for Games"
*/

#include <stdlib.h>
#include <stdio.h>

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif


/* macros */

#define IX(i,j) ((i)+(N+2)*(j))

/* external definitions (from solver.c) */

extern void dens_step ( int N, float * x, float * x0, float * u, float * v, float diff, float dt );
extern void vel_step ( int N, float * u, float * v, float * u0, float * v0, float visc, float dt );

/* global variables */

static int N;
static float dt, diff, visc;
static float force, source;

static float * u, * v, * u_prev, * v_prev;
static float * dens, * dens_prev;

static int win_id;
static int win_x, win_y;
static int mouse_down[3];
static int omx, omy, mx, my;


/*
  ----------------------------------------------------------------------
   free/clear/allocate simulation data
  ----------------------------------------------------------------------
*/


static void free_data ( void )
{
	if ( u ) free ( u );
	if ( v ) free ( v );
	if ( u_prev ) free ( u_prev );
	if ( v_prev ) free ( v_prev );
	if ( dens ) free ( dens );
	if ( dens_prev ) free ( dens_prev );
}

static void clear_data ( void )
{
	int i, size=(N+2)*(N+2);

	for ( i=0 ; i<size ; i++ ) {
		u[i] = v[i] = u_prev[i] = v_prev[i] = dens[i] = dens_prev[i] = 0.0f;
	}
}

static int allocate_data ( void )
{
	int size = (N+2)*(N+2);

	u			= (float *) malloc ( size*sizeof(float) );
	v			= (float *) malloc ( size*sizeof(float) );
	u_prev		= (float *) malloc ( size*sizeof(float) );
	v_prev		= (float *) malloc ( size*sizeof(float) );
	dens		= (float *) malloc ( size*sizeof(float) );
	dens_prev	= (float *) malloc ( size*sizeof(float) );

	if ( !u || !v || !u_prev || !v_prev || !dens || !dens_prev ) {
		fprintf ( stderr, "cannot allocate data\n" );
		return ( 0 );
	}

	return ( 1 );
}


/*
  ----------------------------------------------------------------------
   OpenGL specific drawing routines
  ----------------------------------------------------------------------
*/

static void pre_display ( void )
{

	// Use the Projection Matrix
		glMatrixMode(GL_PROJECTION);

	// Reset Matrix
	glLoadIdentity();

	// Set the viewport to be the entire window
	glViewport(0, 0, win_x, win_y);

	// Set the correct perspective.

	// Prevent a divide by zero, when window is too short
	// (you cant make a window of zero width).
	if (win_y == 0)
		win_y = 1;

	float ratio = win_x * 1.0 / win_y;

	gluPerspective(45.0f, ratio, 0.1f, 100.0f);

	// Get Back to the Modelview
	glMatrixMode(GL_MODELVIEW);
}

static void post_display ( void )
{
	glutSwapBuffers ();
}





void BoundingBox(float origin, float size){
	glLineWidth(1.0);

	glColor3f(1.0f,1.0f,1.0f);
	float neg = origin - size;
	float pos = origin + size;


	glBegin(GL_LINE_LOOP); //front
	glVertex3f(neg, pos, neg); glVertex3f(pos, pos, neg);
	glVertex3f(pos, neg, neg); glVertex3f(neg, neg, neg);
	glEnd();

	glColor3f(1.0f, 0.0f, 0.0f);
	glBegin(GL_LINE_LOOP); //back
	glVertex3f(neg, pos, pos); glVertex3f(pos, pos, pos);
	glVertex3f(pos, neg, pos); glVertex3f(neg, neg, pos);
	glEnd();
	
	glBegin(GL_LINES); //sides
	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex3f(neg, pos, pos); glVertex3f(neg, pos, neg);
	glColor3f(0.0f, 0.0f, 1.0f);
	glVertex3f(pos, pos, pos); glVertex3f(pos, pos, neg);
	glColor3f(1.0f, 1.0f, 0.0f);
	glVertex3f(neg, neg, pos); glVertex3f(neg, neg, neg);
	glColor3f(0.0f, 1.0f, 1.0f);
	glVertex3f(pos, neg, pos); glVertex3f(pos, neg, neg);
	glEnd();
}

float angle = 1.0f;//float angle = 0.0f;
float origin;

static void draw_density ( void )
{

	int i, j;
	float x, y, h, d00, d01, d10, d11;

	h = 2.0f / N;

	float size = (N - 0.5f)*h + h;
	float origin = size / 2;

	// Clear Color and Depth Buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Reset transformations
	glLoadIdentity();


	// Set the camera
	gluLookAt(origin, origin, 7.0f,
		origin, origin, origin,
		0.0f, 1.0f, 0.0f);

	glRotatef(angle, 0.0f, 1.0f, 0.0f);
	
	// Draw Bounding Box

	BoundingBox(origin, origin);

	glBegin ( GL_QUADS );

		for ( i=0 ; i<=N ; i++ ) {
			x = (i-0.5f)*h;
			for ( j=0 ; j<=N ; j++ ) {
				y = (j - 0.5f)*h;

				d00 = dens[IX(i,j)];
				d01 = dens[IX(i,j+1)];
				d10 = dens[IX(i+1,j)];
				d11 = dens[IX(i+1,j+1)];

				glColor4f(d00, d00, d00, 0.0f); glVertex2f ( x, y ); 
				glColor4f(d10, d10, d10, 0.0f); glVertex2f(x + h, y);
				glColor4f(d11, d11, d11, 0.0f); glVertex2f(x + h, y + h);
				glColor4f(d01, d01, d01, 0.0f); glVertex2f(x, y + h);

			}
		}

	glEnd ();
}


static void get_from_UI ( float * d, float * u, float * v )
{
	int i, j, size = (N+2)*(N+2);

	for ( i=0 ; i<size ; i++ ) {
		u[i] = v[i] = d[i] = 0.0f;
	}

	if ( !mouse_down[0] && !mouse_down[2] ) return;

	i = (int)((       mx /(float)win_x)*N+1);
	j = (int)(((win_y-my)/(float)win_y)*N+1);

	if ( i<1 || i>N || j<1 || j>N ) return;

	if ( mouse_down[0] ) {
		u[IX(i,j)] = force * (mx-omx);
		v[IX(i,j)] = force * (omy-my);
	}

	if ( mouse_down[2] ) {
		d[IX(i,j)] = source;
	}

	omx = mx;
	omy = my;

	return;
}



void key_func ( unsigned char key, int x, int y )
{
	switch ( key )
	{
		case 'c':
		case 'C':
			clear_data ();
			break;

		case 'a':
		case 'A':
			angle -= 1.0;
			break;

		case 's':
		case 'S':
			angle += 1.0;
			break;

		case 'q':
		case 'Q':
			free_data ();
			exit ( 0 );
			break;

	}
}

void mouse_func ( int button, int state, int x, int y )
{
	omx = mx = x;
	omx = my = y;

	mouse_down[button] = state == GLUT_DOWN;
}

void motion_func ( int x, int y )
{
	mx = x;
	my = y;
}

void reshape_func ( int width, int height )
{
	glutSetWindow ( win_id );
	glutReshapeWindow ( width, height );

	win_x = width;
	win_y = height;
}

void idle_func ( void )
{
	get_from_UI ( dens_prev, u_prev, v_prev );
	vel_step ( N, u, v, u_prev, v_prev, visc, dt );
	dens_step ( N, dens, dens_prev, u, v, diff, dt );

	glutSetWindow ( win_id );
	glutPostRedisplay ();
}

void display_func ( void )
{
	pre_display ();
	
	draw_density ();

	post_display ();
}



void open_glut_window ( void )
{
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);

	glutInitWindowPosition ( 100, 100 );
	glutInitWindowSize ( win_x, win_y );
	win_id = glutCreateWindow ( "Fluid Smoke simulation" );

	glClearColor ( 0.0f, 0.0f, 0.0f, 1.0f );
	glClear ( GL_COLOR_BUFFER_BIT );
	glutSwapBuffers ();
	glClear ( GL_COLOR_BUFFER_BIT );
	glutSwapBuffers ();

	pre_display ();

	glutKeyboardFunc ( key_func );
	glutMouseFunc ( mouse_func );
	glutMotionFunc ( motion_func );
	glutReshapeFunc ( reshape_func );
	glutIdleFunc ( idle_func );
	glutDisplayFunc ( display_func );
}



int main ( int argc, char ** argv )
{
	glutInit ( &argc, argv );

		N = 128;
		dt = 0.1f;
		diff = 0.0f;
		visc = 0.0001f; // water has viscosity of ~0.9 at 25 deg C / 77 deg F
		force = 5.0f;
		source = 100.0f;

	if ( !allocate_data () ) exit ( 1 );
	clear_data ();

	win_x = 1200;
	win_y = 600;
	open_glut_window (); // Create and open window

	glutMainLoop (); // Loop through registered callbacks

	exit ( 0 );
}
